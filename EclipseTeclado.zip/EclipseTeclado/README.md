# Eclipse Teclado

Teclado Android (PT-BR) com bolha flutuante, teclado flutuante, ditado por voz,
pontuação automática opcional, autocorreção, atalhos de texto e visual eclipse preto e branco.

## Gerar o APK pelo celular (sem instalar nada)
1. Crie um repositório no github.com e envie **todos** os arquivos desta pasta
   (inclusive a pasta `.github`).
2. Abra a aba **Actions → Gerar APK → Run workflow**. Em ~5 min termina.
3. Abra a execução concluída e baixe o artefato **EclipseTeclado-APK** (zip com o `app-debug.apk`).
4. Instale o APK (permita "instalar apps desconhecidos").

## Gerar no computador
Abra a pasta no Android Studio e use Build > Build APK(s),
ou rode `gradle assembleDebug` (Gradle 8.9 + JDK 17).

## Primeiro uso
Abra o app e siga os 4 passos: ativar teclado, escolher teclado, permitir
"sobrepor a outros apps" (bolha/flutuante) e permitir microfone.
