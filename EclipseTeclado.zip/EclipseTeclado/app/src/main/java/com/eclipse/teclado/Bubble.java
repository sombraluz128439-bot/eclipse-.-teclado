package com.eclipse.teclado;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.PixelFormat;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;

/** Bolha flutuante (eclipse animado): toque abre/fecha o teclado, segure para alternar flutuante, arraste para mover. */
final class Bubble {
    private final Context c;
    private final EclipseIME ime;
    private final WindowManager wm;
    private final float dp;
    private final Handler h = new Handler(Looper.getMainLooper());
    private EclipseView v;
    private WindowManager.LayoutParams lp;
    private boolean shown;

    Bubble(Context c, EclipseIME ime) {
        this.c = c;
        this.ime = ime;
        wm = (WindowManager) c.getSystemService(Context.WINDOW_SERVICE);
        dp = c.getResources().getDisplayMetrics().density;
    }

    void show() {
        if (!Prefs.b(c, "bubbleOn") || !Settings.canDrawOverlays(c)) { hide(); return; }
        int size = (int) (Prefs.i(c, "bubbleSize") * dp);
        DisplayMetrics dm = c.getResources().getDisplayMetrics();
        if (!shown) {
            v = new EclipseView(c);
            v.setColors(0xFF000000, 0xFFFFFFFF);
            lp = new WindowManager.LayoutParams(size, size,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                            | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.LEFT;
            int x = Prefs.i(c, "bubbleX"), y = Prefs.i(c, "bubbleY");
            lp.x = x < 0 ? dm.widthPixels - size : x;
            lp.y = y < 0 ? (int) (dm.heightPixels * 0.4f) : y;
            v.setOnTouchListener(touch());
            v.setAlpha(Prefs.i(c, "bubbleAlpha") / 100f);
            try {
                wm.addView(v, lp);
                shown = true;
            } catch (Exception ignored) { }
        } else {
            lp.width = size;
            lp.height = size;
            lp.x = clamp(lp.x, 0, Math.max(0, dm.widthPixels - size));
            lp.y = clamp(lp.y, 0, Math.max(0, dm.heightPixels - size));
            v.setAlpha(Prefs.i(c, "bubbleAlpha") / 100f);
            try { wm.updateViewLayout(v, lp); } catch (Exception ignored) { }
        }
    }

    void hide() {
        if (!shown) return;
        try { wm.removeView(v); } catch (Exception ignored) { }
        shown = false;
    }

    private static int clamp(int a, int lo, int hi) { return Math.max(lo, Math.min(hi, a)); }

    private View.OnTouchListener touch() {
        return new View.OnTouchListener() {
            float dx, dy;
            int sx, sy;
            boolean moved, longDone;
            final Runnable lpr = () -> {
                if (!moved) {
                    longDone = true;
                    v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                    ime.toggleFloat();
                }
            };

            @Override public boolean onTouch(View view, MotionEvent e) {
                DisplayMetrics dm = c.getResources().getDisplayMetrics();
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = lp.x; sy = lp.y; dx = e.getRawX(); dy = e.getRawY();
                        moved = false; longDone = false;
                        h.postDelayed(lpr, 650);
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        if (!moved && Math.hypot(e.getRawX() - dx, e.getRawY() - dy) > 8 * dp) {
                            moved = true;
                            h.removeCallbacks(lpr);
                        }
                        if (moved) {
                            lp.x = clamp((int) (sx + e.getRawX() - dx), 0, dm.widthPixels - lp.width);
                            lp.y = clamp((int) (sy + e.getRawY() - dy), 0, dm.heightPixels - lp.height);
                            try { wm.updateViewLayout(v, lp); } catch (Exception ignored) { }
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        h.removeCallbacks(lpr);
                        if (moved) {
                            int target = lp.x + lp.width / 2 < dm.widthPixels / 2 ? 0 : dm.widthPixels - lp.width;
                            ValueAnimator a = ValueAnimator.ofInt(lp.x, target);
                            a.setDuration(160);
                            a.addUpdateListener(an -> {
                                lp.x = (int) an.getAnimatedValue();
                                try { wm.updateViewLayout(v, lp); } catch (Exception ignored) { }
                            });
                            a.start();
                            Prefs.put(c, "bubbleX", target);
                            Prefs.put(c, "bubbleY", lp.y);
                        } else if (!longDone) {
                            v.animate().scaleX(0.8f).scaleY(0.8f).setDuration(80)
                                    .withEndAction(() -> v.animate().scaleX(1f).scaleY(1f).setDuration(120)).start();
                            ime.toggleKeyboard();
                        }
                        return true;
                    default:
                        h.removeCallbacks(lpr);
                        return true;
                }
            }
        };
    }
}
