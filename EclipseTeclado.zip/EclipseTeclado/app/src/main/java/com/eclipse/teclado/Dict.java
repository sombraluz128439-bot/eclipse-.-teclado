package com.eclipse.teclado;

import android.content.Context;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Dicionário PT-BR, autocorreção, atalhos de texto e palavras aprendidas. */
final class Dict {
    private Dict() {}

    static final String DEF_SNIP = "tdb=tudo bem\nbdia=bom dia\nbtarde=boa tarde\nbnoite=boa noite\n"
            + "att=atenciosamente\nctz=certeza\nvdd=verdade\nnd=nada\ntmj=tamo junto\nsdds=saudades\n"
            + "flw=falou\npdc=pode crer\nagr=agora";

    private static final String WORDS = "que de não um uma para com por mais mas como foi ele ela eu você nós eles elas "
            + "seu sua meu minha nosso nossa este esta esse essa isso isto aquilo aqui ali lá onde quando porque porquê "
            + "então também ainda já só muito muita muitos muitas pouco pouca tudo todo toda todos todas nada algo alguém "
            + "ninguém sempre nunca agora hoje ontem amanhã depois antes durante após sobre entre até desde sem sob contra "
            + "segundo conforme enquanto embora porém contudo todavia entretanto portanto assim logo pois quem qual quais "
            + "quanto quanta cada outro outra outros outras mesmo mesma próprio bom boa bem mal melhor pior grande pequeno "
            + "novo nova velho primeiro última último ser estar ter haver fazer ir ver dar saber querer poder dizer vir ficar "
            + "deixar passar falar achar trazer pensar chegar começar tentar precisar gostar conseguir encontrar esperar "
            + "ajudar trabalhar perguntar responder enviar mandar receber comprar pagar ligar chamar parecer lembrar entender "
            + "escrever ler abrir fechar ouvir sentir viver morar sair entrar voltar levar ganhar perder jogar usar criar "
            + "casa dia tempo vez vida pessoa pessoas trabalho coisa coisas mundo ano anos hora horas noite manhã tarde "
            + "amigo amiga família filho filha mãe pai homem mulher cidade país empresa cliente projeto reunião mensagem "
            + "número telefone email dinheiro problema solução resposta pergunta pedido horário data semana mês "
            + "olá oi obrigado obrigada desculpa desculpe parabéns saudades abraço beijo valeu certo claro verdade "
            + "possível importante necessário disponível informação atenção opinião situação decisão versão função relação "
            + "estou está estão estava estamos tenho tem temos tinha vou vai vamos fui era são sou somos será seria posso "
            + "pode podemos preciso precisa gostaria queria quero quer fazendo feito pode favor bom-dia boa-tarde "
            + "boa-noite tudo-bem pessoal galera gente jeito forma modo parte lado lugar momento começo final fim "
            + "exemplo motivo razão resultado processo sistema serviço produto valor preço pagamento conta mensagem "
            + "arquivo documento foto vídeo imagem texto palavra frase nome sobrenome endereço rua bairro estado "
            + "semana segunda terça quarta quinta sexta sábado domingo janeiro fevereiro março abril maio junho julho "
            + "agosto setembro outubro novembro dezembro";

    private static final String FIXES = "vc=você;vcs=vocês;voce=você;voces=vocês;tb=também;tbm=também;tmb=também;"
            + "tambem=também;nao=não;naum=não;ja=já;so=só;ate=até;entao=então;porem=porém;alem=além;amanha=amanhã;"
            + "ola=olá;pq=porque;q=que;oq=o que;blz=beleza;obg=obrigado;msm=mesmo;mt=muito;mto=muito;hj=hoje;td=tudo;"
            + "fzr=fazer;vlw=valeu;pfv=por favor;cmg=comigo;ctg=contigo;qdo=quando;dps=depois;sao=são;mae=mãe;"
            + "irmao=irmão;coracao=coração;numero=número;ultimo=último;ultima=última;proximo=próximo;proxima=próxima;"
            + "otimo=ótimo;otima=ótima;facil=fácil;dificil=difícil;possivel=possível";

    private static final String[] W = WORDS.split(" ");
    private static final String[] N = new String[W.length];
    private static final HashMap<String, String> FIX = new HashMap<>();

    static {
        for (int i = 0; i < W.length; i++) N[i] = norm(W[i].replace('-', ' '));
        for (String p : FIXES.split(";")) {
            int i = p.indexOf('=');
            if (i > 0) FIX.put(p.substring(0, i), p.substring(i + 1));
        }
    }

    static String norm(String s) {
        return Normalizer.normalize(s, Normalizer.Form.NFD).replaceAll("\\p{M}+", "").toLowerCase(Locale.ROOT);
    }

    /** Correção automática; devolve null se não houver. Resultado em minúsculas. */
    static String fix(String w) {
        String l = w.toLowerCase(Locale.ROOT);
        String f = FIX.get(l);
        if (f != null) return f;
        if (l.length() > 4 && l.endsWith("cao")) return l.substring(0, l.length() - 3) + "ção";
        if (l.length() > 5 && l.endsWith("coes")) return l.substring(0, l.length() - 4) + "ções";
        return null;
    }

    // ---------- palavras aprendidas ----------
    private static HashMap<String, Integer> L;
    private static final HashMap<String, String> NL = new HashMap<>();

    private static void load(Context c) {
        if (L != null) return;
        L = new HashMap<>();
        String s = Prefs.s(c, "learned");
        if (s.isEmpty()) return;
        for (String ln : s.split("\n")) {
            int i = ln.indexOf('\t');
            if (i > 0) {
                try {
                    String k = ln.substring(0, i);
                    L.put(k, Integer.parseInt(ln.substring(i + 1)));
                    NL.put(k, norm(k));
                } catch (Exception ignored) { }
            }
        }
    }

    private static void save(Context c) {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, Integer> e : L.entrySet()) {
            sb.append(e.getKey()).append('\t').append(e.getValue()).append('\n');
        }
        Prefs.put(c, "learned", sb.toString());
    }

    static void learn(Context c, String w) {
        load(c);
        String k = w.toLowerCase(Locale.ROOT);
        if (k.length() < 3 || k.length() > 24) return;
        Integer n = L.get(k);
        L.put(k, n == null ? 1 : n + 1);
        if (n == null) NL.put(k, norm(k));
        if (L.size() > 2000) {
            for (String key : new ArrayList<>(L.keySet())) {
                if (L.get(key) == 1) { L.remove(key); NL.remove(key); break; }
            }
        }
        save(c);
    }

    static void clearLearned(Context c) {
        L = new HashMap<>();
        NL.clear();
        Prefs.put(c, "learned", "");
    }

    static List<String> suggest(Context c, String prefix, int max) {
        load(c);
        ArrayList<String> res = new ArrayList<>();
        if (prefix.isEmpty()) return res;
        String np = norm(prefix);
        boolean cap = Character.isUpperCase(prefix.charAt(0));
        boolean all = prefix.length() > 1 && prefix.equals(prefix.toUpperCase(Locale.ROOT));
        LinkedHashSet<String> out = new LinkedHashSet<>();
        String f = fix(prefix);
        if (f != null) out.add(f);
        ArrayList<Map.Entry<String, Integer>> es = new ArrayList<>();
        for (Map.Entry<String, Integer> e : L.entrySet()) {
            String n = NL.get(e.getKey());
            if (n != null && n.startsWith(np) && !e.getKey().equalsIgnoreCase(prefix)) es.add(e);
        }
        es.sort((a, b) -> b.getValue() - a.getValue());
        for (Map.Entry<String, Integer> e : es) if (e.getValue() >= 2) out.add(e.getKey());
        for (int i = 0; i < W.length && out.size() < max + 4; i++) {
            if (N[i].startsWith(np) && !W[i].equalsIgnoreCase(prefix)) out.add(W[i].replace('-', ' '));
        }
        for (Map.Entry<String, Integer> e : es) if (e.getValue() < 2) out.add(e.getKey());
        for (String s : out) {
            if (res.size() >= max) break;
            if (all) s = s.toUpperCase(Locale.ROOT);
            else if (cap) s = Character.toUpperCase(s.charAt(0)) + s.substring(1);
            res.add(s);
        }
        return res;
    }

    // ---------- atalhos de texto ----------
    private static String snipRaw;
    private static final HashMap<String, String> SN = new HashMap<>();
    private static final ArrayList<String[]> SL = new ArrayList<>();

    private static void snip(Context c) {
        String raw = Prefs.s(c, "snipText");
        if (raw.equals(snipRaw)) return;
        snipRaw = raw;
        SN.clear();
        SL.clear();
        for (String ln : raw.split("\n")) {
            int i = ln.indexOf('=');
            if (i <= 0) continue;
            String k = ln.substring(0, i).trim().toLowerCase(Locale.ROOT);
            String v = ln.substring(i + 1).trim();
            if (k.isEmpty() || v.isEmpty() || k.contains(" ")) continue;
            SN.put(k, v);
            SL.add(new String[]{k, v});
        }
    }

    static String snippet(Context c, String key) {
        snip(c);
        return SN.get(key);
    }

    static List<String[]> snippetList(Context c) {
        snip(c);
        return SL;
    }
}
