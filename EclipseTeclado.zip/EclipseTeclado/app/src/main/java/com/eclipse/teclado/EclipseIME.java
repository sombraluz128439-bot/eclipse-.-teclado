package com.eclipse.teclado;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.inputmethodservice.InputMethodService;
import android.os.SystemClock;
import android.provider.Settings;
import android.text.InputType;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.FrameLayout;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class EclipseIME extends InputMethodService implements KbView.Host, Voice.Cb {

    private static final String COMMA_WORDS = " mas porém contudo todavia entretanto ";
    private static final String[] START = {"Olá", "Tudo bem?", "Obrigado"};
    private static final String[] MID = {"de", "que", "não"};

    private KbView kb;
    private FrameLayout dock, floatRoot;
    private WindowManager wm;
    private WindowManager.LayoutParams flp;
    private boolean floating, floatAttached, safe, lastPunct;
    private int shift;
    private long lastSpace, lastShiftTap;
    private String undoOrig, undoNew, skipFix;
    private Bubble bubble;
    private Voice voice;
    private ClipboardManager cm;
    private ClipboardManager.OnPrimaryClipChangedListener clipL;
    private final ArrayList<String> clips = new ArrayList<>();

    // ------------------------------------------------------------ ciclo de vida
    @Override public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        voice = new Voice(this, this);
        bubble = new Bubble(this, this);
        cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        clipL = this::loadClip;
        cm.addPrimaryClipChangedListener(clipL);
        if (!Prefs.b(this, "bubbleEdit")) bubble.show();
    }

    @Override public void onDestroy() {
        try { cm.removePrimaryClipChangedListener(clipL); } catch (Exception ignored) { }
        voice.destroy();
        bubble.hide();
        setFloatVisible(false);
        super.onDestroy();
    }

    @Override public boolean onEvaluateFullscreenMode() { return false; }

    @Override public View onCreateInputView() {
        dock = new FrameLayout(this);
        kb = new KbView(this, this);
        applyMode();
        return dock;
    }

    @Override public void onStartInput(EditorInfo ei, boolean restarting) {
        super.onStartInput(ei, restarting);
        computeSafe(ei);
        undoNew = null;
        lastPunct = false;
        if (ei != null && ei.inputType != InputType.TYPE_NULL) bubble.show();
    }

    @Override public void onStartInputView(EditorInfo ei, boolean restarting) {
        super.onStartInputView(ei, restarting);
        if (kb == null) return;
        loadClip();
        int cls = ei.inputType & InputType.TYPE_MASK_CLASS;
        boolean numeric = cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE
                || cls == InputType.TYPE_CLASS_DATETIME;
        kb.start(numeric ? 1 : 0);
        applyMode();
        shift = 0;
        autoShift();
        refreshSuggestions();
    }

    @Override public void onFinishInputView(boolean finishingInput) {
        super.onFinishInputView(finishingInput);
        voice.stop();
        setFloatVisible(false);
    }

    @Override public void onFinishInput() {
        super.onFinishInput();
        voice.stop();
        if (Prefs.b(this, "bubbleEdit")) bubble.hide();
    }

    private void computeSafe(EditorInfo ei) {
        safe = false;
        if (ei == null) return;
        int cls = ei.inputType & InputType.TYPE_MASK_CLASS;
        int var = ei.inputType & InputType.TYPE_MASK_VARIATION;
        if (cls != InputType.TYPE_CLASS_TEXT) { safe = true; return; }
        if (var == InputType.TYPE_TEXT_VARIATION_PASSWORD
                || var == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                || var == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD
                || var == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
                || var == InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS
                || var == InputType.TYPE_TEXT_VARIATION_URI
                || (ei.inputType & InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS) != 0) {
            safe = true;
        }
    }

    // ------------------------------------------------------------ modo encaixado / flutuante
    private void applyMode() {
        if (kb == null || dock == null) return;
        boolean want = Prefs.b(this, "floatMode") && Settings.canDrawOverlays(this);
        if (kb.getParent() != null) ((ViewGroup) kb.getParent()).removeView(kb);
        floating = want;
        dock.removeAllViews();
        if (floating) {
            dock.addView(new View(this), new FrameLayout.LayoutParams(-1, 1));
            ensureFloat();
            floatRoot.removeAllViews();
            kb.setFloating(true);
            floatRoot.addView(kb, new FrameLayout.LayoutParams(-1, -2));
            updateFloatLayout();
            setFloatVisible(true);
        } else {
            setFloatVisible(false);
            kb.setFloating(false);
            dock.addView(kb, new FrameLayout.LayoutParams(-1, -2));
        }
    }

    private void ensureFloat() {
        Th th = Th.of(Prefs.i(this, "theme"));
        if (floatRoot == null) {
            floatRoot = new FrameLayout(this);
            GradientDrawable bgd = new GradientDrawable();
            bgd.setCornerRadius(16 * getResources().getDisplayMetrics().density);
            floatRoot.setBackground(bgd);
            GradientDrawable fg = new GradientDrawable();
            fg.setCornerRadius(16 * getResources().getDisplayMetrics().density);
            fg.setStroke((int) getResources().getDisplayMetrics().density, 0x88888888);
            floatRoot.setForeground(fg);
            floatRoot.setClipToOutline(true);
            flp = new WindowManager.LayoutParams(-2, -2,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                            | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                    PixelFormat.TRANSLUCENT);
            flp.gravity = Gravity.TOP | Gravity.LEFT;
        }
        ((GradientDrawable) floatRoot.getBackground()).setColor(th.bg);
    }

    private void updateFloatLayout() {
        if (floatRoot == null) return;
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int sw = dm.widthPixels, sh = dm.heightPixels;
        flp.width = (int) (sw * Prefs.i(this, "floatW") / 100f);
        flp.height = WindowManager.LayoutParams.WRAP_CONTENT;
        int x = Prefs.i(this, "floatX"), y = Prefs.i(this, "floatY");
        if (x < 0) x = (sw - flp.width) / 2;
        if (y < 0) y = (int) (sh * 0.5f);
        flp.x = clamp(x, 0, Math.max(0, sw - flp.width));
        flp.y = clamp(y, 0, Math.max(0, sh - (int) (80 * dm.density)));
        if (floatAttached) {
            try { wm.updateViewLayout(floatRoot, flp); } catch (Exception ignored) { }
        }
    }

    private void setFloatVisible(boolean on) {
        if (floatRoot == null) return;
        if (on && floating) {
            if (!floatAttached) {
                try {
                    wm.addView(floatRoot, flp);
                    floatAttached = true;
                } catch (Exception e) {
                    toast("Não foi possível abrir o teclado flutuante");
                }
            }
        } else if (floatAttached) {
            try { wm.removeView(floatRoot); } catch (Exception ignored) { }
            floatAttached = false;
        }
    }

    private static int clamp(int a, int lo, int hi) { return Math.max(lo, Math.min(hi, a)); }

    void toggleKeyboard() {
        if (isInputViewShown()) requestHideSelf(0);
        else requestShowSelf(0);
    }

    @Override public void toggleFloat() {
        boolean nf = !Prefs.b(this, "floatMode");
        if (nf && !Settings.canDrawOverlays(this)) {
            toast("Ative \"Sobrepor a outros apps\" para usar o teclado flutuante");
            openApp(false);
            return;
        }
        Prefs.put(this, "floatMode", nf);
        if (kb != null) applyMode();
        else requestShowSelf(0);
    }

    @Override public void hide() { requestHideSelf(0); }

    @Override public void drag(float dx, float dy, boolean end) {
        if (!floatAttached) return;
        DisplayMetrics dm = getResources().getDisplayMetrics();
        flp.x = clamp(flp.x + Math.round(dx), 0, Math.max(0, dm.widthPixels - flp.width));
        flp.y = clamp(flp.y + Math.round(dy), 0, Math.max(0, dm.heightPixels - (int) (80 * dm.density)));
        try { wm.updateViewLayout(floatRoot, flp); } catch (Exception ignored) { }
        if (end) {
            Prefs.put(this, "floatX", flp.x);
            Prefs.put(this, "floatY", flp.y);
        }
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    private void openApp(boolean mic) {
        Intent i = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        if (mic) i.putExtra("mic", true);
        try { startActivity(i); } catch (Exception ignored) { }
    }

    // ------------------------------------------------------------ utilidades de texto
    private InputConnection ic() { return getCurrentInputConnection(); }

    private String before(int n) {
        InputConnection c = ic();
        if (c == null) return "";
        CharSequence s = c.getTextBeforeCursor(n, 0);
        return s == null ? "" : s.toString();
    }

    private static String lastWord(String b) {
        int i = b.length();
        while (i > 0 && Character.isLetter(b.charAt(i - 1))) i--;
        return b.substring(i);
    }

    private static boolean capNeeded(String b) {
        if (b.isEmpty()) return true;
        char last = b.charAt(b.length() - 1);
        if (last == '\n') return true;
        if (!Character.isWhitespace(last)) return false;
        int i = b.length() - 1;
        while (i >= 0 && Character.isWhitespace(b.charAt(i))) i--;
        return i < 0 || ".!?".indexOf(b.charAt(i)) >= 0;
    }

    private static String keepCase(String orig, String rep) {
        if (orig.length() > 1 && orig.equals(orig.toUpperCase(Locale.ROOT))) return rep.toUpperCase(Locale.ROOT);
        if (!orig.isEmpty() && Character.isUpperCase(orig.charAt(0)) && !rep.isEmpty()) {
            return Character.toUpperCase(rep.charAt(0)) + rep.substring(1);
        }
        return rep;
    }

    private void autoShift() {
        if (kb == null) return;
        if (shift == 2) { kb.setShift(2); return; }
        boolean cap = !safe && Prefs.b(this, "autoCap") && capNeeded(before(4));
        shift = cap ? 1 : 0;
        kb.setShift(shift);
    }

    private void refreshSuggestions() {
        if (kb == null) return;
        if (safe || !Prefs.b(this, "suggest")) { kb.setSuggestions(new ArrayList<String>()); return; }
        String b = before(40);
        String w = lastWord(b);
        List<String> l;
        if (w.isEmpty()) {
            l = new ArrayList<>();
            for (String s : capNeeded(b) ? START : MID) l.add(s);
        } else {
            l = Dict.suggest(this, w, 3);
        }
        kb.setSuggestions(l);
    }

    private void after() {
        if (shift == 1) shift = 0;
        autoShift();
        refreshSuggestions();
    }

    // ------------------------------------------------------------ teclas (KbView.Host)
    @Override public void key(String s) {
        InputConnection c = ic();
        if (c == null || s.isEmpty()) return;
        undoNew = null;
        if (!safe && s.length() == 1) {
            char ch = s.charAt(0);
            if (".,;:!?".indexOf(ch) >= 0) { punct(c, ch); return; }
            if (lastPunct && Character.isLetter(ch) && Prefs.b(this, "punct") && Prefs.b(this, "spaceFix")) {
                String b = before(30);
                if (!b.isEmpty()) {
                    char p = b.charAt(b.length() - 1);
                    if (".,;:!?".indexOf(p) >= 0) {
                        boolean ok = true;
                        if (p == '.') {
                            ok = b.length() < 2 || !Character.isDigit(b.charAt(b.length() - 2));
                            String l = b.toLowerCase(Locale.ROOT);
                            if (l.contains("http") || l.contains("www") || l.contains("@")) ok = false;
                        }
                        if (ok) {
                            c.commitText(" ", 1);
                            if (".!?".indexOf(p) >= 0 && Prefs.b(this, "autoCap")) s = s.toUpperCase(Locale.ROOT);
                        }
                    }
                }
            }
        }
        lastPunct = false;
        c.commitText(s, 1);
        after();
    }

    private void punct(InputConnection c, char ch) {
        if (Prefs.b(this, "punct") && Prefs.b(this, "spaceFix")) {
            String b = before(4);
            int n = 0;
            while (n < b.length() && b.charAt(b.length() - 1 - n) == ' ') n++;
            if (n > 0 && n < b.length()) c.deleteSurroundingText(n, 0);
        }
        c.commitText(String.valueOf(ch), 1);
        lastPunct = true;
        undoNew = null;
        after();
    }

    @Override public void space() {
        InputConnection c = ic();
        if (c == null) return;
        long now = SystemClock.uptimeMillis();
        if (!safe) {
            String b = before(60);
            boolean punctOn = Prefs.b(this, "punct");
            // espaço duplo vira ponto
            if (punctOn && Prefs.b(this, "dblSpace") && now - lastSpace < 650 && b.length() >= 2
                    && b.endsWith(" ") && Character.isLetterOrDigit(b.charAt(b.length() - 2))) {
                c.deleteSurroundingText(1, 0);
                c.commitText(". ", 1);
                lastSpace = 0;
                lastPunct = false;
                undoNew = null;
                after();
                return;
            }
            String w = lastWord(b);
            if (!w.isEmpty()) {
                String lw = w.toLowerCase(Locale.ROOT);
                String rep = null;
                boolean skip = skipFix != null && skipFix.equals(lw);
                skipFix = null;
                if (!skip && Prefs.b(this, "snippets")) rep = Dict.snippet(this, lw);
                if (!skip && rep == null && Prefs.b(this, "autoCorrect")) rep = Dict.fix(w);
                if (rep != null) {
                    rep = keepCase(w, rep);
                    c.deleteSurroundingText(w.length(), 0);
                    c.commitText(rep + " ", 1);
                    undoOrig = w;
                    undoNew = rep;
                    lastSpace = now;
                    lastPunct = false;
                    after();
                    return;
                }
                // vírgula automática antes de "mas", "porém"...
                if (punctOn && Prefs.b(this, "autoComma") && COMMA_WORDS.contains(" " + lw + " ")) {
                    int idx = b.length() - w.length();
                    if (idx >= 2 && b.charAt(idx - 1) == ' ' && Character.isLetterOrDigit(b.charAt(idx - 2))) {
                        c.deleteSurroundingText(w.length() + 1, 0);
                        c.commitText(", " + w + " ", 1);
                        lastSpace = now;
                        lastPunct = false;
                        undoNew = null;
                        after();
                        return;
                    }
                }
                if (Prefs.b(this, "learn")) Dict.learn(this, w);
            }
        }
        c.commitText(" ", 1);
        lastSpace = now;
        lastPunct = false;
        undoNew = null;
        after();
    }

    @Override public void backspace(boolean word) {
        InputConnection c = ic();
        if (c == null) return;
        if (!word && undoNew != null) {
            String b = before(undoNew.length() + 2);
            if (b.endsWith(undoNew + " ")) {
                c.deleteSurroundingText(undoNew.length() + 1, 0);
                c.commitText(undoOrig, 1);
                skipFix = undoOrig.toLowerCase(Locale.ROOT);
                undoNew = null;
                undoOrig = null;
                lastPunct = false;
                autoShift();
                refreshSuggestions();
                return;
            }
        }
        undoNew = null;
        if (word) {
            String b = before(40);
            int i = b.length();
            while (i > 0 && Character.isWhitespace(b.charAt(i - 1))) i--;
            while (i > 0 && !Character.isWhitespace(b.charAt(i - 1))) i--;
            int n = b.length() - i;
            if (n > 0) c.deleteSurroundingText(n, 0);
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL);
        }
        lastPunct = false;
        autoShift();
        refreshSuggestions();
    }

    @Override public void enter() {
        if (ic() == null) return;
        if (!sendDefaultEditorAction(true)) sendKeyChar('\n');
        lastPunct = false;
        undoNew = null;
        autoShift();
        refreshSuggestions();
    }

    @Override public void cursor(int dir) {
        sendDownUpKeyEvents(dir < 0 ? KeyEvent.KEYCODE_DPAD_LEFT : KeyEvent.KEYCODE_DPAD_RIGHT);
        undoNew = null;
        lastPunct = false;
        refreshSuggestions();
    }

    @Override public void shift() {
        long n = SystemClock.uptimeMillis();
        if (shift == 1 && n - lastShiftTap < 400) shift = 2;
        else shift = shift == 0 ? 1 : 0;
        lastShiftTap = n;
        if (kb != null) kb.setShift(shift);
    }

    @Override public void pick(String s) {
        InputConnection c = ic();
        if (c == null) return;
        String w = lastWord(before(40));
        if (!w.isEmpty()) c.deleteSurroundingText(w.length(), 0);
        c.commitText(s + " ", 1);
        if (!safe && Prefs.b(this, "learn") && s.length() >= 3 && Character.isLetter(s.charAt(0))) Dict.learn(this, s);
        lastSpace = 0;
        lastPunct = false;
        undoNew = null;
        after();
    }

    @Override public void paste(String s) {
        InputConnection c = ic();
        if (c == null) return;
        c.commitText(s, 1);
        lastPunct = false;
        undoNew = null;
        after();
    }

    @Override public void tool(int id) {
        InputConnection c = ic();
        switch (id) {
            case KbView.T_ALL: if (c != null) c.performContextMenuAction(android.R.id.selectAll); break;
            case KbView.T_COPY: if (c != null) c.performContextMenuAction(android.R.id.copy); break;
            case KbView.T_PASTE: if (c != null) c.performContextMenuAction(android.R.id.paste); break;
            case KbView.T_CUT: if (c != null) c.performContextMenuAction(android.R.id.cut); break;
            case KbView.T_BIG:
            case KbView.T_SMALL: {
                int d = id == KbView.T_BIG ? 1 : -1;
                if (floating) Prefs.put(this, "floatW", clamp(Prefs.i(this, "floatW") + 6 * d, 55, 100));
                else Prefs.put(this, "keyH", clamp(Prefs.i(this, "keyH") + 3 * d, 38, 72));
                if (kb != null) { kb.rebuild(); updateFloatLayout(); }
                break;
            }
            case KbView.T_SETTINGS: openApp(false); break;
            default: break;
        }
    }

    // ------------------------------------------------------------ área de transferência
    private void loadClip() {
        try {
            ClipData d = cm.getPrimaryClip();
            if (d != null && d.getItemCount() > 0) {
                CharSequence t = d.getItemAt(0).coerceToText(this);
                if (t != null) addClip(t.toString());
            }
        } catch (Exception ignored) { }
    }

    private void addClip(String t) {
        if (t == null || t.trim().isEmpty() || t.length() > 2000) return;
        clips.remove(t);
        clips.add(0, t);
        while (clips.size() > 12) clips.remove(clips.size() - 1);
        if (kb != null) kb.setClips(clips);
    }

    // ------------------------------------------------------------ voz
    @Override public void mic() {
        if (voice.active()) { voice.stop(); return; }
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            toast("Permita o microfone no app Eclipse Teclado");
            openApp(true);
            return;
        }
        voice.start(Prefs.b(this, "voiceCont"));
    }

    @Override public void partial(String s) { if (kb != null) kb.setPartial(s); }
    @Override public void state(boolean on) { if (kb != null) kb.setListening(on); }
    @Override public void error(String m) { toast(m); }

    @Override public void result(String s) {
        InputConnection c = ic();
        if (c == null || s == null) return;
        String t = s.trim();
        if (t.isEmpty()) return;
        if (Prefs.b(this, "voiceCmds")) t = voiceFix(t);
        String b = before(3);
        boolean cap = Prefs.b(this, "autoCap");
        if (cap) t = capSentences(t, capNeeded(b));
        if (!b.isEmpty() && !Character.isWhitespace(b.charAt(b.length() - 1)) && ",.;:!?)".indexOf(t.charAt(0)) < 0
                && t.charAt(0) != '\n') {
            t = " " + t;
        }
        if (Prefs.b(this, "voicePeriod") && t.trim().split("\\s+").length >= 4
                && ".!?:;,\n".indexOf(t.charAt(t.length() - 1)) < 0) {
            t += ".";
        }
        if (!t.endsWith("\n")) t += " ";
        c.commitText(t, 1);
        lastPunct = false;
        undoNew = null;
        after();
    }

    private static String voiceFix(String t) {
        String[][] m = {
                {"(?iU)\\s*\\bponto de interrogação\\b", "?"},
                {"(?iU)\\s*\\binterrogação\\b", "?"},
                {"(?iU)\\s*\\bponto de exclamação\\b", "!"},
                {"(?iU)\\s*\\bexclamação\\b", "!"},
                {"(?iU)\\s*\\bponto e vírgula\\b", ";"},
                {"(?iU)\\s*\\bdois pontos\\b", ":"},
                {"(?iU)\\s*\\bv[íi]rgula\\b", ","},
                {"(?iU)\\s*\\bponto final\\b", "."},
                {"(?iU)\\s*\\bponto\\s*$", "."},
                {"(?iU)\\s*\\breticências\\b", "..."},
                {"(?iU)\\s*\\b(nova linha|próxima linha)\\b\\s*", "\n"},
                {"(?iU)\\s*\\bnovo parágrafo\\b\\s*", "\n\n"},
                {"(?iU)\\babre parênteses\\s*", "("},
                {"(?iU)\\s*\\bfecha parênteses\\b", ")"}
        };
        for (String[] p : m) t = t.replaceAll(p[0], p[1]);
        return t.replaceAll("([,;:.!?])(?=\\p{L})", "$1 ");
    }

    private static String capSentences(String t, boolean first) {
        StringBuilder sb = new StringBuilder(t);
        boolean cap = first;
        for (int i = 0; i < sb.length(); i++) {
            char ch = sb.charAt(i);
            if (cap && Character.isLetter(ch)) { sb.setCharAt(i, Character.toUpperCase(ch)); cap = false; }
            else if (".!?\n".indexOf(ch) >= 0) cap = true;
            else if (!Character.isWhitespace(ch)) cap = false;
        }
        return sb.toString();
    }
}
