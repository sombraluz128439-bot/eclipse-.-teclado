package com.eclipse.teclado;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.view.View;
import android.view.animation.LinearInterpolator;

/** Eclipse animado em preto e branco: disco escuro, coroa pulsante, raios girando e brilho de "anel de diamante". */
final class EclipseView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private ValueAnimator va;
    private float t, inten = 1f, k = 1f;
    private int disc = 0xFF000000, fg = 0xFFFFFFFF;
    private boolean animOn = true;
    private RadialGradient glow;

    EclipseView(Context c) { super(c); }

    void setColors(int disc, int fg) { this.disc = disc; this.fg = fg; buildGlow(); invalidate(); }
    void setIntensity(float v) { inten = v; invalidate(); }
    void setScale(float v) { k = v; buildGlow(); invalidate(); }
    void setAnimated(boolean b) { animOn = b; update(); }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) { buildGlow(); }
    @Override protected void onAttachedToWindow() { super.onAttachedToWindow(); update(); }
    @Override protected void onDetachedFromWindow() { if (va != null) va.cancel(); super.onDetachedFromWindow(); }

    private void buildGlow() {
        int w = getWidth(), h = getHeight();
        if (w == 0 || h == 0) return;
        float R = Math.min(w, h) / 2f * k;
        int rgb = fg & 0x00FFFFFF;
        glow = new RadialGradient(w / 2f, h / 2f, R, new int[]{rgb, rgb, 0xFF000000 | rgb, rgb},
                new float[]{0f, 0.5f, 0.58f, 1f}, Shader.TileMode.CLAMP);
    }

    private void update() {
        if (animOn && isAttachedToWindow()) {
            if (va == null) {
                va = ValueAnimator.ofFloat(0f, 1f);
                va.setDuration(9000);
                va.setRepeatCount(ValueAnimator.INFINITE);
                va.setInterpolator(new LinearInterpolator());
                va.addUpdateListener(a -> { t = (float) a.getAnimatedValue(); invalidate(); });
            }
            if (!va.isStarted()) va.start();
        } else if (va != null) {
            va.cancel();
        }
        invalidate();
    }

    @Override protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        if (w == 0 || h == 0) return;
        if (glow == null) buildGlow();
        float cx = w / 2f, cy = h / 2f, R = Math.min(w, h) / 2f * k, r = R * 0.52f;
        double tau = Math.PI * 2;
        float pulse = 0.78f + 0.22f * (float) Math.sin(t * tau);

        // coroa
        p.setStyle(Paint.Style.FILL);
        p.setShader(glow);
        p.setAlpha((int) (255 * Math.min(1f, pulse * inten)));
        c.drawCircle(cx, cy, R, p);
        p.setShader(null);

        // raios
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeWidth(Math.max(1f, R * 0.012f));
        p.setColor(fg);
        c.save();
        c.rotate(t * 360f, cx, cy);
        for (int i = 0; i < 24; i++) {
            double a = i * tau / 24;
            float s = (float) Math.abs(Math.sin(i * 1.7 + t * tau * 3));
            float len = r * (1.15f + 0.3f * s);
            p.setAlpha((int) (200 * inten * (0.35f + 0.65f * s)));
            c.drawLine(cx + (float) Math.cos(a) * r * 1.1f, cy + (float) Math.sin(a) * r * 1.1f,
                    cx + (float) Math.cos(a) * len, cy + (float) Math.sin(a) * len, p);
        }
        c.restore();

        // disco
        p.setStyle(Paint.Style.FILL);
        p.setColor(disc);
        c.drawCircle(cx, cy, r, p);

        // aro fino
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(Math.max(1.5f, R * 0.035f));
        p.setColor(fg);
        p.setAlpha((int) (255 * Math.min(1f, 0.5f + 0.5f * inten)));
        c.drawCircle(cx, cy, r, p);

        // brilho "anel de diamante"
        double ang = -Math.PI / 4 + Math.sin(t * tau) * 0.4;
        float sx = cx + (float) Math.cos(ang) * r, sy = cy + (float) Math.sin(ang) * r;
        p.setStyle(Paint.Style.FILL);
        p.setColor(fg);
        p.setAlpha((int) (70 * inten));
        c.drawCircle(sx, sy, R * 0.09f, p);
        p.setAlpha((int) (140 * inten));
        c.drawCircle(sx, sy, R * 0.055f, p);
        p.setAlpha((int) (255 * Math.min(1f, inten + 0.2f)));
        c.drawCircle(sx, sy, R * 0.03f, p);
    }
}
