package com.eclipse.teclado;

import android.content.Context;
import android.media.AudioManager;
import android.os.Handler;
import android.os.Looper;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/** Interface do teclado (usada tanto encaixada quanto flutuante). */
final class KbView extends FrameLayout {

    interface Host {
        void key(String s);
        void space();
        void backspace(boolean word);
        void enter();
        void cursor(int dir);
        void shift();
        void mic();
        void toggleFloat();
        void hide();
        void pick(String s);
        void tool(int id);
        void paste(String s);
        void drag(float dx, float dy, boolean end);
    }

    static final int T_ALL = 1, T_COPY = 2, T_PASTE = 3, T_CUT = 4, T_BIG = 5, T_SMALL = 6, T_SETTINGS = 7;

    private static final HashMap<String, String> ALT = new HashMap<>();
    static {
        ALT.put("a", "áàâãä"); ALT.put("e", "éêèë"); ALT.put("i", "íîï"); ALT.put("o", "óôõò");
        ALT.put("u", "úüù"); ALT.put("c", "ç"); ALT.put("n", "ñ");
        ALT.put(".", ",?!:;'\"()-…");
    }

    private static final String EMOJI = "😀 😁 😂 🤣 😊 😍 😘 😎 😉 🙂 😅 😭 😢 😡 🤔 😴 🥰 😇 🙏 👍 👎 👏 🙌 💪 "
            + "👋 ✌️ 🤝 ❤️ 💔 🔥 ✨ ⭐ 🎉 🎂 🎁 ☀️ 🌙 🌟 💡 ✅ ❌ ⚠️ 📌 📞 💬 🚀 💰 🏠 🚗 ⚽ 🍕 ☕ 🍺 🐶 🐱";

    private static final View.OnTouchListener PRESS = (v, e) -> {
        if (v instanceof Key) {
            int a = e.getActionMasked();
            ((Key) v).setPressedLook(a == MotionEvent.ACTION_DOWN || a == MotionEvent.ACTION_MOVE);
        }
        return false;
    };

    private final Host host;
    private final float dp;
    private final Handler h = new Handler(Looper.getMainLooper());
    private Th th;
    private int keyH, page, shift;
    private float textPx;
    private boolean floating, listening;
    private String partial = "";
    private List<String> sugs = new ArrayList<>();
    private List<String> alts = null;
    private List<String> clips = new ArrayList<>();
    private LinearLayout content, sugBox;
    private Key micKey, shiftKey;
    private final List<Key> letters = new ArrayList<>();

    KbView(Context c, Host host) {
        super(c);
        this.host = host;
        dp = c.getResources().getDisplayMetrics().density;
        render();
    }

    // ------------------------------------------------------------ API
    void rebuild() { render(); }
    void start(int p) { page = p; render(); }
    void setFloating(boolean b) { if (floating != b) { floating = b; render(); } }
    void setPage(int p) { page = p; render(); }

    void setShift(int s) {
        shift = s;
        for (Key k : letters) {
            k.label = s != 0 ? k.base.toUpperCase() : k.base;
            k.invalidate();
        }
        if (shiftKey != null) { shiftKey.state = s; shiftKey.invalidate(); }
    }

    void setSuggestions(List<String> l) {
        sugs = l;
        if (alts == null && !listening) refreshBar();
    }

    void setPartial(String s) {
        partial = s == null ? "" : s;
        if (listening) refreshBar();
    }

    void setListening(boolean b) {
        listening = b;
        partial = "";
        if (micKey != null) { micKey.kind = b ? 2 : 1; micKey.flat = !b; micKey.invalidate(); }
        refreshBar();
    }

    void setClips(List<String> l) {
        clips = l;
        if (page == 4) render();
    }

    // ------------------------------------------------------------ construção
    private void render() {
        Context c = getContext();
        removeAllViews();
        letters.clear();
        shiftKey = null; micKey = null; sugBox = null; alts = null;
        th = Th.of(Prefs.i(c, "theme"));
        keyH = (int) (Prefs.i(c, "keyH") * dp);
        textPx = keyH * 0.40f * Prefs.i(c, "txt") / 100f;
        setBackgroundColor(th.bg);
        if (Prefs.b(c, "anim")) {
            EclipseView bg = new EclipseView(c);
            bg.setColors(th.bg, th.text);
            bg.setIntensity(0.30f);
            bg.setScale(1.9f);
            addView(bg, new LayoutParams(-1, -1));
        }
        content = new LinearLayout(c);
        content.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (3 * dp);
        content.setPadding(pad, 0, pad, (int) (6 * dp));
        addView(content, new LayoutParams(-1, -2));
        bar();
        switch (page) {
            case 1: symbols(0); break;
            case 2: symbols(1); break;
            case 3: emoji(); break;
            case 4: tools(); break;
            default: letterPage(); break;
        }
        listeningSync();
    }

    private void listeningSync() {
        if (micKey != null) { micKey.kind = listening ? 2 : 1; micKey.flat = !listening; }
    }

    private LinearLayout row() {
        LinearLayout l = new LinearLayout(getContext());
        l.setOrientation(LinearLayout.HORIZONTAL);
        content.addView(l, new LinearLayout.LayoutParams(-1, keyH));
        return l;
    }

    private void add(LinearLayout r, View k, float w) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -1, w);
        int m = (int) (2 * dp);
        lp.setMargins(m, m, m, m);
        r.addView(k, lp);
    }

    private void addFixed(LinearLayout r, View k, int w) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(w, -1);
        int m = (int) (2 * dp);
        lp.setMargins(m, m, m, m);
        r.addView(k, lp);
    }

    private Key mk() { return new Key(getContext(), th, textPx); }

    private Key iconKey(int ic, int kind) {
        Key k = mk();
        k.icon = ic;
        k.kind = kind;
        k.setOnTouchListener(PRESS);
        return k;
    }

    private Key text(String t, int kind, Runnable a) {
        Key k = mk();
        k.label = t;
        k.kind = kind;
        k.setOnTouchListener(PRESS);
        if (a != null) k.setOnClickListener(v -> { fb(v); a.run(); });
        return k;
    }

    private Key charKey(String s, boolean letter) {
        Key k = mk();
        k.base = s;
        k.label = letter && shift != 0 ? s.toUpperCase() : s;
        if (letter) letters.add(k);
        k.setOnTouchListener(PRESS);
        k.setOnClickListener(v -> {
            fb(v);
            if (alts != null) { alts = null; refreshBar(); }
            host.key(((Key) v).label);
        });
        final String set = ALT.get(s);
        if (set != null) {
            k.setOnLongClickListener(v -> {
                fb(v);
                ArrayList<String> l = new ArrayList<>();
                for (char ch : set.toCharArray()) {
                    String a = String.valueOf(ch);
                    l.add(letter && shift != 0 ? a.toUpperCase() : a);
                }
                alts = l;
                refreshBar();
                return true;
            });
        }
        return k;
    }

    private Key spaceKey() {
        Key k = mk();
        k.label = "Eclipse";
        k.setOnTouchListener(new KT(false));
        return k;
    }

    private Key delKey() {
        Key k = iconKey(Key.I_BACK, 1);
        k.setOnTouchListener(new KT(true));
        return k;
    }

    private static String[] sp(String s) { return s.split(" "); }

    // ------------------------------------------------------------ barra superior
    private void bar() {
        Context c = getContext();
        int bw = (int) (keyH * 0.9f);
        LinearLayout b = new LinearLayout(c);
        b.setOrientation(LinearLayout.HORIZONTAL);
        content.addView(b, new LinearLayout.LayoutParams(-1, bw));

        if (floating) {
            Key hd = iconKey(Key.I_HANDLE, 1);
            hd.flat = true;
            hd.setOnTouchListener(dragTouch());
            addFixed(b, hd, bw);
        }
        micKey = iconKey(Key.I_MIC, listening ? 2 : 1);
        micKey.flat = !listening;
        micKey.setOnClickListener(v -> { fb(v); host.mic(); });
        addFixed(b, micKey, bw);

        sugBox = new LinearLayout(c);
        sugBox.setOrientation(LinearLayout.HORIZONTAL);
        b.addView(sugBox, new LinearLayout.LayoutParams(0, -1, 1f));

        Key t = iconKey(Key.I_TOOLS, page == 4 ? 2 : 1);
        t.flat = page != 4;
        t.setOnClickListener(v -> { fb(v); page = page == 4 ? 0 : 4; render(); });
        addFixed(b, t, bw);

        Key f = iconKey(Key.I_FLOAT, floating ? 2 : 1);
        f.flat = !floating;
        f.setOnClickListener(v -> { fb(v); host.toggleFloat(); });
        addFixed(b, f, bw);

        Key ch = iconKey(Key.I_CHEV, 1);
        ch.flat = true;
        ch.setOnClickListener(v -> { fb(v); host.hide(); });
        addFixed(b, ch, bw);
        refreshBar();
    }

    private void refreshBar() {
        if (sugBox == null) return;
        sugBox.removeAllViews();
        if (alts != null) {
            for (String a : alts) sugBox.addView(chip(a, () -> {
                host.key(a);
                alts = null;
                post(this::refreshBar);
            }), lp1());
            return;
        }
        if (listening) {
            String t = partial.isEmpty() ? "Ouvindo… fale agora" : partial;
            if (t.length() > 34) t = "…" + t.substring(t.length() - 34);
            sugBox.addView(chip(t, null), lp1());
            return;
        }
        for (int i = 0; i < 3; i++) {
            final String s = i < sugs.size() ? sugs.get(i) : "";
            sugBox.addView(chip(s, s.isEmpty() ? null : () -> host.pick(s)), lp1());
        }
    }

    private LinearLayout.LayoutParams lp1() { return new LinearLayout.LayoutParams(0, -1, 1f); }

    private Key chip(String s, Runnable a) {
        Key k = new Key(getContext(), th, textPx * 0.9f);
        k.label = s;
        k.flat = true;
        if (a != null) {
            k.setOnTouchListener(PRESS);
            k.setOnClickListener(v -> { fb(v); a.run(); });
        }
        return k;
    }

    private View.OnTouchListener dragTouch() {
        return new View.OnTouchListener() {
            float lx, ly;
            @Override public boolean onTouch(View v, MotionEvent e) {
                Key k = (Key) v;
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        lx = e.getRawX(); ly = e.getRawY(); k.setPressedLook(true);
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        host.drag(e.getRawX() - lx, e.getRawY() - ly, false);
                        lx = e.getRawX(); ly = e.getRawY();
                        return true;
                    default:
                        k.setPressedLook(false);
                        host.drag(0, 0, true);
                        return true;
                }
            }
        };
    }

    // ------------------------------------------------------------ páginas
    private void letterPage() {
        boolean nr = Prefs.b(getContext(), "numRow");
        if (nr) {
            LinearLayout r = row();
            for (String d : sp("1 2 3 4 5 6 7 8 9 0")) add(r, charKey(d, false), 1f);
        }
        LinearLayout r1 = row();
        for (String s : sp("q w e r t y u i o p")) add(r1, charKey(s, true), 1f);
        LinearLayout r2 = row();
        for (String s : sp("a s d f g h j k l ç")) add(r2, charKey(s, true), 1f);
        LinearLayout r3 = row();
        shiftKey = iconKey(Key.I_SHIFT, 1);
        shiftKey.state = shift;
        shiftKey.setOnClickListener(v -> { fb(v); host.shift(); });
        add(r3, shiftKey, 1.5f);
        for (String s : sp("z x c v b n m")) add(r3, charKey(s, true), 1f);
        add(r3, delKey(), 1.5f);
        bottomRow("?123", 1);
    }

    private void bottomRow(String firstLabel, int firstTarget) {
        LinearLayout r = row();
        add(r, text(firstLabel, 1, () -> { page = firstTarget; render(); }), 1.4f);
        add(r, charKey(",", false), 1f);
        Key em = iconKey(Key.I_SMILE, 1);
        em.setOnClickListener(v -> { fb(v); page = page == 3 ? 0 : 3; render(); });
        add(r, em, 1f);
        add(r, spaceKey(), 4f);
        add(r, charKey(".", false), 1f);
        Key en = iconKey(Key.I_ENTER, 2);
        en.setOnClickListener(v -> { fb(v); host.enter(); });
        add(r, en, 1.4f);
    }

    private void symbols(int p) {
        boolean nr = Prefs.b(getContext(), "numRow");
        List<String[]> mid = new ArrayList<>();
        String[] last;
        if (p == 0) {
            mid.add(sp("1 2 3 4 5 6 7 8 9 0"));
            mid.add(sp("@ # $ _ & - + ( ) /"));
            if (nr) mid.add(sp("% < > { } [ ] \\ | ~"));
            last = sp("* \" ' : ; ! ?");
        } else {
            mid.add(sp("€ £ ¥ ° ¢ © ® ™ § ¶"));
            mid.add(sp("= ^ • √ π ÷ × ∆ ≈ ±"));
            if (nr) mid.add(sp("1 2 3 4 5 6 7 8 9 0"));
            last = sp("¿ ¡ « » … ` ´");
        }
        for (String[] a : mid) {
            LinearLayout r = row();
            for (String s : a) add(r, charKey(s, false), 1f);
        }
        LinearLayout r = row();
        add(r, text(p == 0 ? "=\\<" : "?123", 1, () -> { page = page == 1 ? 2 : 1; render(); }), 1.5f);
        for (String s : last) add(r, charKey(s, false), 1f);
        add(r, delKey(), 1.5f);
        bottomRow("ABC", 0);
    }

    private void emoji() {
        Context c = getContext();
        int rows = (Prefs.b(c, "numRow") ? 5 : 4) - 1;
        ScrollView sv = new ScrollView(c);
        sv.setVerticalScrollBarEnabled(false);
        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        sv.addView(col);
        String[] e = sp(EMOJI);
        for (int i = 0; i < e.length; i += 8) {
            LinearLayout r = new LinearLayout(c);
            r.setOrientation(LinearLayout.HORIZONTAL);
            col.addView(r, new LinearLayout.LayoutParams(-1, keyH));
            for (int j = i; j < i + 8; j++) {
                if (j < e.length) {
                    final String em = e[j];
                    Key k = text(em, 0, () -> host.paste(em));
                    k.flat = true;
                    add(r, k, 1f);
                } else {
                    add(r, new View(c), 1f);
                }
            }
        }
        content.addView(sv, new LinearLayout.LayoutParams(-1, keyH * rows));
        LinearLayout r = row();
        add(r, text("ABC", 1, () -> { page = 0; render(); }), 1.5f);
        add(r, spaceKey(), 5f);
        add(r, delKey(), 1.5f);
    }

    private Key tog(String label, String key) {
        final boolean on = Prefs.b(getContext(), key);
        return text(label, on ? 2 : 1, () -> { Prefs.put(getContext(), key, !on); render(); });
    }

    private void tools() {
        LinearLayout r1 = row();
        String[] n = {"Sel. tudo", "Copiar", "Colar", "Cortar"};
        int[] id = {T_ALL, T_COPY, T_PASTE, T_CUT};
        for (int i = 0; i < 4; i++) {
            final int t = id[i];
            add(r1, text(n[i], 1, () -> host.tool(t)), 1f);
        }
        LinearLayout r2 = row();
        add(r2, tog("Pontuação", "punct"), 1f);
        add(r2, tog("Autocorrigir", "autoCorrect"), 1f);
        add(r2, tog("Sugestões", "suggest"), 1f);
        add(r2, tog("Voz contínua", "voiceCont"), 1f);
        LinearLayout r3 = row();
        add(r3, text("−", 1, () -> host.tool(T_SMALL)), 1f);
        add(r3, text("+", 1, () -> host.tool(T_BIG)), 1f);
        add(r3, text("Ajustes", 1, () -> host.tool(T_SETTINGS)), 1.5f);
        add(r3, text("ABC", 2, () -> { page = 0; render(); }), 1.5f);

        ArrayList<String> cl = new ArrayList<>(), cv = new ArrayList<>();
        for (String s : clips) {
            String one = s.replace('\n', ' ').trim();
            cl.add(one.length() > 16 ? one.substring(0, 16) + "…" : one);
            cv.add(s);
        }
        chips(cl, cv, "Área de transferência vazia");
        ArrayList<String> sl = new ArrayList<>(), sv = new ArrayList<>();
        for (String[] p : Dict.snippetList(getContext())) { sl.add(p[0]); sv.add(p[1]); }
        chips(sl, sv, "Sem atalhos de texto");
    }

    private void chips(List<String> labels, List<String> values, String empty) {
        Context c = getContext();
        HorizontalScrollView hs = new HorizontalScrollView(c);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout in = new LinearLayout(c);
        in.setOrientation(LinearLayout.HORIZONTAL);
        hs.addView(in);
        content.addView(hs, new LinearLayout.LayoutParams(-1, keyH));
        int m = (int) (2 * dp);
        if (labels.isEmpty()) {
            Key k = text(empty, 0, null);
            k.flat = true;
            in.addView(k, new LinearLayout.LayoutParams((int) (240 * dp), -1));
            return;
        }
        for (int i = 0; i < labels.size(); i++) {
            final String val = values.get(i);
            Key k = text(labels.get(i), 0, () -> host.paste(val));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams((int) (110 * dp), -1);
            lp.setMargins(m, m, m, m);
            in.addView(k, lp);
        }
    }

    // ------------------------------------------------------------ feedback
    private void fb(View v) {
        Context c = getContext();
        if (Prefs.b(c, "haptic")) {
            v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP,
                    HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING);
        }
        if (Prefs.b(c, "sound")) {
            AudioManager am = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
            if (am != null) am.playSoundEffect(AudioManager.FX_KEYPRESS_STANDARD);
        }
    }

    /** Toque especial: apagar (repete e desliza p/ apagar palavra) e espaço (desliza p/ mover cursor). */
    private final class KT implements View.OnTouchListener {
        final boolean del;
        float x0, lx;
        boolean moved, wordDone;
        int n;
        final Runnable rep = new Runnable() {
            @Override public void run() {
                host.backspace(false);
                n++;
                h.postDelayed(this, n > 10 ? 30 : 65);
            }
        };

        KT(boolean del) { this.del = del; }

        @Override public boolean onTouch(View v, MotionEvent e) {
            Key k = (Key) v;
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    k.setPressedLook(true);
                    fb(v);
                    x0 = lx = e.getX();
                    moved = false; wordDone = false; n = 0;
                    if (del) {
                        host.backspace(false);
                        h.postDelayed(rep, 380);
                    }
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (!del) {
                        float d = e.getX() - lx;
                        if (Math.abs(d) > 16 * dp) {
                            host.cursor(d > 0 ? 1 : -1);
                            lx = e.getX();
                            moved = true;
                        }
                    } else if (!wordDone && e.getX() - x0 < -60 * dp) {
                        wordDone = true;
                        h.removeCallbacks(rep);
                        host.backspace(true);
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    if (!del && !moved) host.space();
                    k.setPressedLook(false);
                    h.removeCallbacks(rep);
                    return true;
                default:
                    k.setPressedLook(false);
                    h.removeCallbacks(rep);
                    return true;
            }
        }
    }
}
