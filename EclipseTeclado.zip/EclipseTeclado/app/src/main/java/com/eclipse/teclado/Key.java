package com.eclipse.teclado;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

/** Tecla desenhada à mão (texto ou ícone vetorial). kind: 0 normal, 1 especial, 2 destaque. */
final class Key extends View {
    static final int I_NONE = 0, I_MIC = 1, I_CHEV = 2, I_FLOAT = 3, I_TOOLS = 4, I_SHIFT = 5,
            I_BACK = 6, I_ENTER = 7, I_HANDLE = 8, I_SMILE = 9;

    String label = "", base = "";
    int icon, kind, state;
    boolean flat, down;

    private final Th th;
    private final float dp, textPx;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private final Path path = new Path();

    Key(Context c, Th th, float textPx) {
        super(c);
        this.th = th;
        this.textPx = textPx;
        dp = c.getResources().getDisplayMetrics().density;
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeCap(Paint.Cap.ROUND);
        line.setStrokeJoin(Paint.Join.ROUND);
        line.setStrokeWidth(2f * dp);
        fill.setStyle(Paint.Style.FILL);
        txt.setTextAlign(Paint.Align.CENTER);
    }

    void setPressedLook(boolean b) {
        if (down != b) { down = b; invalidate(); }
    }

    @Override protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        int fg = kind == 2 ? th.accentText : th.text;
        if (!flat || down) {
            int bgc = down ? th.press : kind == 2 ? th.text : kind == 1 ? th.special : th.key;
            if (down) fg = th.text;
            r.set(0, 0, w, h);
            float rad = 8 * dp;
            fill.setColor(bgc);
            c.drawRoundRect(r, rad, rad, fill);
            if (th.outline && !flat) {
                line.setStrokeWidth(dp);
                line.setColor(0x77FFFFFF);
                r.inset(dp / 2, dp / 2);
                c.drawRoundRect(r, rad, rad, line);
                line.setStrokeWidth(2f * dp);
            }
        }
        float cx = w / 2f, cy = h / 2f;
        if (icon != 0) {
            drawIcon(c, cx, cy, Math.min(w, h) * 0.27f, fg);
        } else if (!label.isEmpty()) {
            float ts = label.codePointCount(0, label.length()) > 2 ? textPx * 0.75f : textPx;
            txt.setColor(fg);
            txt.setTextSize(ts);
            while (txt.measureText(label) > w - 6 * dp && ts > 9 * dp) {
                ts -= dp;
                txt.setTextSize(ts);
            }
            Paint.FontMetrics fm = txt.getFontMetrics();
            c.drawText(label, cx, cy - (fm.ascent + fm.descent) / 2f, txt);
        }
    }

    private void drawIcon(Canvas c, float cx, float cy, float s, int fg) {
        line.setColor(fg);
        fill.setColor(fg);
        path.reset();
        switch (icon) {
            case I_MIC:
                r.set(cx - s * .35f, cy - s * .95f, cx + s * .35f, cy + s * .15f);
                c.drawRoundRect(r, s * .35f, s * .35f, line);
                r.set(cx - s * .7f, cy - s * .35f, cx + s * .7f, cy + s * .55f);
                c.drawArc(r, 0, 180, false, line);
                c.drawLine(cx, cy + s * .55f, cx, cy + s * .95f, line);
                c.drawLine(cx - s * .4f, cy + s * .95f, cx + s * .4f, cy + s * .95f, line);
                break;
            case I_CHEV:
                path.moveTo(cx - s * .7f, cy - s * .3f);
                path.lineTo(cx, cy + s * .4f);
                path.lineTo(cx + s * .7f, cy - s * .3f);
                c.drawPath(path, line);
                break;
            case I_FLOAT:
                r.set(cx - s * .2f, cy - s * .75f, cx + s * .85f, cy + s * .2f);
                c.drawRoundRect(r, s * .15f, s * .15f, line);
                r.set(cx - s * .85f, cy - s * .2f, cx + s * .2f, cy + s * .75f);
                c.drawRoundRect(r, s * .15f, s * .15f, line);
                break;
            case I_TOOLS:
                for (int i = -1; i <= 1; i += 2)
                    for (int j = -1; j <= 1; j += 2)
                        c.drawCircle(cx + i * s * .45f, cy + j * s * .45f, s * .22f, fill);
                break;
            case I_SHIFT:
                path.moveTo(cx, cy - s * .85f);
                path.lineTo(cx - s * .8f, cy + s * .05f);
                path.lineTo(cx - s * .35f, cy + s * .05f);
                path.lineTo(cx - s * .35f, cy + s * .7f);
                path.lineTo(cx + s * .35f, cy + s * .7f);
                path.lineTo(cx + s * .35f, cy + s * .05f);
                path.lineTo(cx + s * .8f, cy + s * .05f);
                path.close();
                c.drawPath(path, line);
                if (state > 0) c.drawPath(path, fill);
                if (state == 2) c.drawLine(cx - s * .35f, cy + s * 1.0f, cx + s * .35f, cy + s * 1.0f, line);
                break;
            case I_BACK:
                path.moveTo(cx - s * .95f, cy);
                path.lineTo(cx - s * .4f, cy - s * .65f);
                path.lineTo(cx + s * .9f, cy - s * .65f);
                path.lineTo(cx + s * .9f, cy + s * .65f);
                path.lineTo(cx - s * .4f, cy + s * .65f);
                path.close();
                c.drawPath(path, line);
                c.drawLine(cx - s * .05f, cy - s * .3f, cx + s * .5f, cy + s * .3f, line);
                c.drawLine(cx + s * .5f, cy - s * .3f, cx - s * .05f, cy + s * .3f, line);
                break;
            case I_ENTER:
                path.moveTo(cx + s * .8f, cy - s * .6f);
                path.lineTo(cx + s * .8f, cy + s * .2f);
                path.lineTo(cx - s * .7f, cy + s * .2f);
                c.drawPath(path, line);
                path.reset();
                path.moveTo(cx - s * .2f, cy - s * .35f);
                path.lineTo(cx - s * .7f, cy + s * .2f);
                path.lineTo(cx - s * .2f, cy + s * .75f);
                c.drawPath(path, line);
                break;
            case I_HANDLE:
                for (int i = -1; i <= 1; i++)
                    for (int j = 0; j <= 1; j++)
                        c.drawCircle(cx + (j == 0 ? -1 : 1) * s * .35f, cy + i * s * .55f, s * .16f, fill);
                break;
            case I_SMILE:
                c.drawCircle(cx, cy, s * .85f, line);
                c.drawCircle(cx - s * .32f, cy - s * .2f, s * .1f, fill);
                c.drawCircle(cx + s * .32f, cy - s * .2f, s * .1f, fill);
                r.set(cx - s * .45f, cy - s * .25f, cx + s * .45f, cy + s * .45f);
                c.drawArc(r, 25, 130, false, line);
                break;
            default:
                break;
        }
    }
}
