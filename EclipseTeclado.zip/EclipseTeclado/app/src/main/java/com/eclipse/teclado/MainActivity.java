package com.eclipse.teclado;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

/** Ativação e ajustes do Eclipse Teclado. */
public class MainActivity extends Activity {
    private LinearLayout root;
    private float d;
    private final Button[] steps = new Button[4];
    private static final String[] STEP_NAMES = {
            "1. Ativar o teclado", "2. Escolher como teclado atual",
            "3. Permitir bolha e teclado flutuante", "4. Permitir microfone (voz)"};

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        d = getResources().getDisplayMetrics().density;
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Color.BLACK);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(24), dp(18), dp(48));
        sv.addView(root);
        setContentView(sv);
        build();
        if (getIntent().getBooleanExtra("mic", false)) askMic();
    }

    @Override protected void onResume() {
        super.onResume();
        refresh();
    }

    @Override public void onRequestPermissionsResult(int rc, String[] p, int[] r) {
        super.onRequestPermissionsResult(rc, p, r);
        refresh();
    }

    // ---------------------------------------------------------------- helpers
    private int dp(int v) { return (int) (v * d + 0.5f); }

    private GradientDrawable box(int fill) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setStroke(dp(1), 0x66FFFFFF);
        g.setCornerRadius(dp(12));
        return g;
    }

    private TextView tv(String t, int sp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(sp);
        v.setTextColor(color);
        if (bold) v.setTypeface(v.getTypeface(), android.graphics.Typeface.BOLD);
        return v;
    }

    private void add(View v, int top) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(top);
        root.addView(v, lp);
    }

    private void section(String t) { add(tv(t.toUpperCase(), 12, 0xFF9A9A9A, true), 26); }

    private Button btn(String label, Runnable r) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setBackground(box(0xFF0F0F0F));
        b.setOnClickListener(v -> r.run());
        add(b, 8);
        return b;
    }

    private void sw(String label, String desc, String key) {
        Switch s = new Switch(this);
        s.setText(label);
        s.setTextSize(15);
        s.setTextColor(Color.WHITE);
        s.setChecked(Prefs.b(this, key));
        s.setOnCheckedChangeListener((v, on) -> Prefs.put(this, key, on));
        add(s, 12);
        if (desc != null) add(tv(desc, 12, 0xFF8A8A8A, false), 2);
    }

    private void seek(String label, String key, int min, int max, String unit) {
        final TextView t = tv(label + ": " + Prefs.i(this, key) + unit, 15, Color.WHITE, false);
        add(t, 14);
        SeekBar s = new SeekBar(this);
        s.setMax(max - min);
        s.setProgress(Prefs.i(this, key) - min);
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int p, boolean u) {
                t.setText(label + ": " + (p + min) + unit);
                if (u) Prefs.put(MainActivity.this, key, p + min);
            }
            @Override public void onStartTrackingTouch(SeekBar sb) { }
            @Override public void onStopTrackingTouch(SeekBar sb) { }
        });
        add(s, 2);
    }

    // ---------------------------------------------------------------- tela
    private void build() {
        EclipseView e = new EclipseView(this);
        e.setColors(Color.BLACK, Color.WHITE);
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(dp(150), dp(150));
        ep.gravity = Gravity.CENTER_HORIZONTAL;
        root.addView(e, ep);
        TextView title = tv("Eclipse Teclado", 26, Color.WHITE, true);
        title.setGravity(Gravity.CENTER);
        add(title, 0);
        TextView sub = tv("Escreva certo, rápido e do seu jeito", 14, 0xFF9A9A9A, false);
        sub.setGravity(Gravity.CENTER);
        add(sub, 4);

        section("Ativação (faça uma vez)");
        Runnable[] acts = {
                () -> startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)),
                () -> ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE)).showInputMethodPicker(),
                () -> startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()))),
                this::askMic};
        for (int i = 0; i < 4; i++) steps[i] = btn(STEP_NAMES[i], acts[i]);

        add(tv("TESTAR", 12, 0xFF9A9A9A, true), 26);
        EditText t = new EditText(this);
        t.setHint("Toque aqui para testar o teclado");
        t.setHintTextColor(0xFF777777);
        t.setTextColor(Color.WHITE);
        t.setBackground(box(0xFF0F0F0F));
        t.setPadding(dp(14), dp(12), dp(14), dp(12));
        t.setMinLines(3);
        t.setGravity(Gravity.TOP);
        t.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        add(t, 8);

        section("Pontuação automática");
        sw("Pontuação automática", "Desligue para o teclado não mexer em vírgulas, pontos e espaços.", "punct");
        sw("Espaço duplo vira ponto final", null, "dblSpace");
        sw("Vírgula antes de mas, porém, contudo…", "Ex.: \"quero ir mas não posso\" vira \"quero ir, mas não posso\".", "autoComma");
        sw("Ajustar espaços da pontuação", "Tira o espaço antes do ponto/vírgula e põe depois.", "spaceFix");
        sw("Maiúscula depois do ponto", null, "autoCap");

        section("Escrita rápida");
        sw("Autocorreção", "vc → você, nao → não, informacao → informação…", "autoCorrect");
        sw("Sugestões de palavras", null, "suggest");
        sw("Aprender minhas palavras", null, "learn");
        btn("Apagar palavras aprendidas", () -> {
            Dict.clearLearned(this);
            Toast.makeText(this, "Palavras aprendidas apagadas", Toast.LENGTH_SHORT).show();
        });
        sw("Atalhos de texto", "Digite o atalho e dê espaço: tdb → tudo bem.", "snippets");
        btn("Editar meus atalhos", this::editSnippets);
        sw("Linha de números", null, "numRow");

        section("Voz");
        sw("Ditado contínuo", "Fica ouvindo até você tocar no microfone de novo.", "voiceCont");
        sw("Comandos falados", "Diga: vírgula, ponto final, interrogação, nova linha, novo parágrafo.", "voiceCmds");
        sw("Ponto final automático em frases longas", null, "voicePeriod");

        section("Bolha");
        sw("Mostrar bolha", "Toque: abre/fecha o teclado. Segure: liga/desliga o teclado flutuante. Arraste: move.", "bubbleOn");
        sw("Só aparecer ao digitar", null, "bubbleEdit");
        seek("Tamanho", "bubbleSize", 40, 90, " dp");
        seek("Transparência", "bubbleAlpha", 30, 100, "%");

        section("Teclado flutuante");
        sw("Usar teclado flutuante", "Arraste pela alça de pontinhos e coloque onde quiser.", "floatMode");
        seek("Largura", "floatW", 55, 100, "%");
        btn("Voltar ao centro da tela", () -> {
            Prefs.put(this, "floatX", -1);
            Prefs.put(this, "floatY", -1);
        });

        section("Aparência");
        btn("Tema do teclado", this::pickTheme);
        sw("Eclipse animado no fundo", null, "anim");
        seek("Altura das teclas", "keyH", 38, 72, " dp");
        seek("Tamanho das letras", "txt", 70, 140, "%");
        sw("Vibração ao tocar", null, "haptic");
        sw("Som ao tocar", null, "sound");

        add(tv("Dica: no teclado, o ícone de grade (⠿) abre ferramentas: copiar/colar, histórico da área de transferência e atalhos.",
                12, 0xFF8A8A8A, false), 28);
    }

    private void pickTheme() {
        String[] n = {"Eclipse escuro", "Eclipse claro", "Contorno (preto e branco)"};
        new AlertDialog.Builder(this).setTitle("Tema")
                .setSingleChoiceItems(n, Prefs.i(this, "theme"), (dlg, which) -> {
                    Prefs.put(this, "theme", which);
                    dlg.dismiss();
                }).show();
    }

    private void editSnippets() {
        final EditText et = new EditText(this);
        et.setText(Prefs.s(this, "snipText"));
        et.setMinLines(8);
        et.setGravity(Gravity.TOP);
        et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        new AlertDialog.Builder(this).setTitle("Atalhos (um por linha: atalho=texto)")
                .setView(et)
                .setPositiveButton("Salvar", (dlg, w) -> Prefs.put(this, "snipText", et.getText().toString()))
                .setNegativeButton("Cancelar", null).show();
    }

    // ---------------------------------------------------------------- permissões / status
    private void askMic() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 1);
        }
    }

    private void refresh() {
        boolean enabled = false;
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        for (InputMethodInfo i : imm.getEnabledInputMethodList()) {
            if (i.getPackageName().equals(getPackageName())) enabled = true;
        }
        String def = Settings.Secure.getString(getContentResolver(), Settings.Secure.DEFAULT_INPUT_METHOD);
        boolean selected = def != null && def.startsWith(getPackageName() + "/");
        boolean[] ok = {enabled, selected, Settings.canDrawOverlays(this),
                checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED};
        for (int i = 0; i < 4; i++) steps[i].setText((ok[i] ? "✓  " : "○  ") + STEP_NAMES[i]);
    }
}
