package com.eclipse.teclado;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.HashMap;

final class Prefs {
    private Prefs() {}

    static final HashMap<String, Object> DEF = new HashMap<>();
    static {
        String[] on = {"autoCap", "punct", "dblSpace", "autoComma", "spaceFix", "autoCorrect", "snippets",
                "suggest", "learn", "numRow", "haptic", "anim", "bubbleOn", "bubbleEdit",
                "voiceCont", "voiceCmds", "voicePeriod"};
        for (String k : on) DEF.put(k, true);
        DEF.put("sound", false);
        DEF.put("floatMode", false);
        DEF.put("theme", 0);
        DEF.put("keyH", 50);
        DEF.put("txt", 100);
        DEF.put("bubbleSize", 60);
        DEF.put("bubbleAlpha", 100);
        DEF.put("bubbleX", -1);
        DEF.put("bubbleY", -1);
        DEF.put("floatX", -1);
        DEF.put("floatY", -1);
        DEF.put("floatW", 92);
        DEF.put("snipText", Dict.DEF_SNIP);
    }

    static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences("eclipse", Context.MODE_PRIVATE);
    }

    static boolean b(Context c, String k) {
        Object d = DEF.get(k);
        return sp(c).getBoolean(k, d instanceof Boolean && (Boolean) d);
    }

    static int i(Context c, String k) {
        Object d = DEF.get(k);
        return sp(c).getInt(k, d instanceof Integer ? (Integer) d : 0);
    }

    static String s(Context c, String k) {
        Object d = DEF.get(k);
        return sp(c).getString(k, d instanceof String ? (String) d : "");
    }

    static void put(Context c, String k, boolean v) { sp(c).edit().putBoolean(k, v).apply(); }
    static void put(Context c, String k, int v) { sp(c).edit().putInt(k, v).apply(); }
    static void put(Context c, String k, String v) { sp(c).edit().putString(k, v).apply(); }
}
