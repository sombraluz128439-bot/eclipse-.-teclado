package com.eclipse.teclado;

/** Temas preto e branco do teclado. */
final class Th {
    int bg, key, press, special, text, accentText;
    boolean outline;

    static Th of(int t) {
        Th h = new Th();
        if (t == 1) {            // Eclipse claro
            h.bg = 0xFFFFFFFF; h.key = 0xDDEDEDED; h.press = 0xFFB5B5B5; h.special = 0xDDD6D6D6;
            h.text = 0xFF000000; h.accentText = 0xFFFFFFFF;
        } else if (t == 2) {     // Contorno (AMOLED)
            h.bg = 0xFF000000; h.key = 0x00000000; h.press = 0xFF3A3A3A; h.special = 0x00000000;
            h.text = 0xFFFFFFFF; h.accentText = 0xFF000000; h.outline = true;
        } else {                 // Eclipse escuro
            h.bg = 0xFF000000; h.key = 0xCC1C1C1C; h.press = 0xFF555555; h.special = 0xCC303030;
            h.text = 0xFFFFFFFF; h.accentText = 0xFF000000;
        }
        return h;
    }
}
