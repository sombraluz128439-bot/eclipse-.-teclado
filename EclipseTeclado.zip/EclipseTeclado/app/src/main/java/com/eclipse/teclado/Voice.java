package com.eclipse.teclado;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import java.util.ArrayList;

/** Ditado por voz em PT-BR, com modo contínuo (reinicia sozinho). */
final class Voice implements RecognitionListener {

    interface Cb {
        void partial(String s);
        void result(String s);
        void state(boolean on);
        void error(String m);
    }

    private final Context c;
    private final Cb cb;
    private final Handler h = new Handler(Looper.getMainLooper());
    private SpeechRecognizer sr;
    private boolean active, cont;

    Voice(Context c, Cb cb) { this.c = c; this.cb = cb; }

    boolean active() { return active; }

    void start(boolean continuous) {
        if (!SpeechRecognizer.isRecognitionAvailable(c)) {
            cb.error("Reconhecimento de voz indisponível neste aparelho");
            return;
        }
        cont = continuous;
        active = true;
        cb.state(true);
        begin();
    }

    void stop() {
        if (!active) return;
        active = false;
        h.removeCallbacksAndMessages(null);
        cb.state(false);
        try { if (sr != null) sr.stopListening(); } catch (Exception ignored) { }
    }

    void destroy() {
        active = false;
        h.removeCallbacksAndMessages(null);
        if (sr != null) {
            try { sr.destroy(); } catch (Exception ignored) { }
            sr = null;
        }
    }

    private void begin() {
        if (!active) return;
        try {
            if (sr == null) {
                sr = SpeechRecognizer.createSpeechRecognizer(c);
                sr.setRecognitionListener(this);
            }
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR");
            i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
            i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
            i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, c.getPackageName());
            sr.startListening(i);
        } catch (Exception e) {
            active = false;
            cb.state(false);
            cb.error("Não foi possível iniciar a voz");
        }
    }

    private static String first(Bundle b) {
        ArrayList<String> l = b == null ? null : b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        return l == null || l.isEmpty() ? null : l.get(0);
    }

    @Override public void onPartialResults(Bundle b) {
        String s = first(b);
        if (s != null) cb.partial(s);
    }

    @Override public void onResults(Bundle b) {
        String s = first(b);
        cb.partial("");
        if (s != null) cb.result(s);
        if (active && cont) {
            h.postDelayed(this::begin, 120);
        } else if (active) {
            active = false;
            cb.state(false);
        }
    }

    @Override public void onError(int e) {
        if (!active) return;
        switch (e) {
            case SpeechRecognizer.ERROR_NO_MATCH:
            case SpeechRecognizer.ERROR_SPEECH_TIMEOUT:
                if (cont) { h.postDelayed(this::begin, 200); return; }
                break;
            case SpeechRecognizer.ERROR_RECOGNIZER_BUSY:
                try { if (sr != null) sr.cancel(); } catch (Exception ignored) { }
                h.postDelayed(this::begin, 500);
                return;
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS:
                cb.error("Permita o microfone no app Eclipse Teclado");
                break;
            case SpeechRecognizer.ERROR_NETWORK:
            case SpeechRecognizer.ERROR_NETWORK_TIMEOUT:
                cb.error("Sem conexão para reconhecer a voz");
                break;
            default:
                cb.error("Erro de voz (" + e + ")");
                break;
        }
        active = false;
        cb.partial("");
        cb.state(false);
    }

    @Override public void onReadyForSpeech(Bundle b) { }
    @Override public void onBeginningOfSpeech() { }
    @Override public void onRmsChanged(float v) { }
    @Override public void onBufferReceived(byte[] buf) { }
    @Override public void onEndOfSpeech() { }
    @Override public void onEvent(int t, Bundle b) { }
}
